const carousel = document.querySelector('.carousel');
const images = document.querySelectorAll('.carousel img');
const prevBtn = document.querySelector('.prev-btn');
const nextBtn = document.querySelector('.next-btn');
let index = 0;

function updateCarousel() {
  images.forEach((img, i) => {
    img.style.display = i === index ? 'block' : 'none';
  });
}

prevBtn.addEventListener('click', () => {
  index = (index === 0) ? images.length - 1 : index - 1;
  updateCarousel();
});

nextBtn.addEventListener('click', () => {
  index = (index === images.length - 1) ? 0 : index + 1;
  updateCarousel();
});

// Inicializa o carrossel
updateCarousel();
